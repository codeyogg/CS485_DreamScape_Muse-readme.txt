const Memories = () => {
    return <h1>Home</h1>;
  };
  
  export default Memories;


  